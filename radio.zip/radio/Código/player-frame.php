
		<div id="box_rp">
	<div class="chair-avatar" title="Storm" >
	<div class="avatar"
	style="background-image:url(https://www.habbo.com.br/habbo-imaging/avatarimage?&figure=cc-3007-110-110.ch-3167-92.sh-3016-110.hd-180-10.hr-828-53.lg-3057-1425&action=sit&gesture=std&direction=2&head_direction=2&size=s);">
	</div>
	</div>


	<div class="box_pp">
	<div class="play"></div>
	</div>

	<div class="separator"></div>

	<div id="box_infos">
	<div class="music"><div class="t">Love me like you...</div></div>
	<div class="room"><div class="t">Aquele Cafezinho</div></div>
	<div class="listeners"><div class="t">203</div></div>
	</div>

	<div class="button_close" title="fechar"></div>

	<div class="next_dj"></div>
	</div>